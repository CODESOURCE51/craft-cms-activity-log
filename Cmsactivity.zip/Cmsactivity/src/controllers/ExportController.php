<?php

namespace Inspire\Cmsactivity\controllers;

use Inspire\Cmsactivity\Cmsactivity;
use craft\web\Controller;

/**
 * @since 2.3.0
 */
class ExportController extends Controller
{
    /**
     * Index action
     */
    public function actionIndex()
    {
        $this->requirePermission('viewActivityLogs');
        $type = $this->request->getRequiredParam('type');
        $filters = $this->request->getParam('filters', []);
        $exporter = Cmsactivity::$plugin->exporters->getByHandle($type);
        $query = Cmsactivity::$plugin->logs->getLogsQuery($filters);
        Cmsactivity::$plugin->twigContext = 'export';
        $logs = array_map(function ($record) {
            return $record->toModel();
        }, $query->all());
        $content = $exporter->getExportContent($logs);
        $name = 'export-' . (new \DateTime())->format('YmdHis') . '.' . $exporter->extension;
        return $this->response->sendContentAsFile($content, $name, ['mimeType' => $exporter->mimeType]);
    }
}
