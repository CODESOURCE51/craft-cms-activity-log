<?php

namespace Inspire\Cmsactivity\traits;

use Inspire\Cmsactivity\models\fieldHandlers\elements\Neo;
use Inspire\Cmsactivity\models\fieldHandlers\projectConfig\FieldLayout;
use Inspire\Cmsactivity\models\fieldHandlers\projectConfig\NeoGroup;
use Inspire\Cmsactivity\models\logs\fields\NeoBlockCreated;
use Inspire\Cmsactivity\models\logs\fields\NeoBlockDeleted;
use Inspire\Cmsactivity\models\logs\fields\NeoBlockGroupCreated;
use Inspire\Cmsactivity\models\logs\fields\NeoBlockGroupDeleted;
use Inspire\Cmsactivity\models\logs\fields\NeoBlockGroupSaved;
use Inspire\Cmsactivity\models\logs\fields\NeoBlockSaved;
use Inspire\Cmsactivity\recorders\NeoBlockGroups;
use Inspire\Cmsactivity\recorders\NeoBlocks;
use Inspire\Cmsactivity\services\FieldHandlers;
use Inspire\Cmsactivity\services\Fields;
use Inspire\Cmsactivity\services\Recorders;
use Inspire\Cmsactivity\services\Types;
use yii\base\Event;

/**
 * @since 2.3.1
 */
trait NeoField
{
    /**
     * Register everything needed for Neo fields tracking
     */
    protected function initNeoField()
    {
        Event::on(Fields::class, Fields::EVENT_REGISTER_FIELD_LABELS, function (Event $event) {
            $categories = array_keys(\Craft::$app->i18n->translations);
            $category = in_array('neo', $categories) ? 'neo' : 'cmsactivity';
            $event->labels['benf\\neo\\Field'] = [
                'settings.minBlocks' => \Craft::t($category, 'Min Blocks'),
                'settings.maxBlocks' => \Craft::t($category, 'Max Blocks'),
                'settings.minTopBlocks' => \Craft::t($category, 'Min Top-Level Blocks'),
                'settings.maxTopBlocks' => \Craft::t($category, 'Max Top-Level Blocks'),
                'settings.minLevels' => \Craft::t($category, 'Min Levels'),
                'settings.maxLevels' => \Craft::t($category, 'Max Levels')
            ];
        });
        Event::on(Fields::class, Fields::EVENT_REGISTER_TRACKED_FIELDS, function (Event $event) {
            $event->tracked['benf\\neo\\Field'] = ['settings.minBlocks', 'settings.maxBlocks', 'settings.minTopBlocks', 'settings.maxTopBlocks', 'settings.minLevels', 'settings.maxLevels'];
        });
        Event::on(FieldHandlers::class, FieldHandlers::EVENT_REGISTER_ELEMENT_HANDLERS, function (Event $event) {
            $event->add(Neo::class);
        });
        Event::on(FieldHandlers::class, FieldHandlers::EVENT_REGISTER_PROJECTCONFIG_HANDLERS, function (Event $event) {
            $event->add(NeoGroup::class);
        });
        Event::on(FieldLayout::class, FieldLayout::EVENT_REGISTER_TARGETS, function (Event $event) {
            $event->targets[] = 'neo.blockTypes.{uid}.fieldLayouts';
        });
        Event::on(Recorders::class, Recorders::EVENT_REGISTER, function (Event $event) {
            $event->add('neoBlocks', new NeoBlocks());
            $event->add('neoBlockGroups', new NeoBlockGroups());
        });
        Event::on(Types::class, Types::EVENT_REGISTER, function (Event $event) {
            $event->add(new NeoBlockCreated());
            $event->add(new NeoBlockSaved());
            $event->add(new NeoBlockDeleted());
            $event->add(new NeoBlockGroupCreated());
            $event->add(new NeoBlockGroupSaved());
            $event->add(new NeoBlockGroupDeleted());
        });
    }
}
