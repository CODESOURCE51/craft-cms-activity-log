<?php

namespace Inspire\Cmsactivity\base\logs;

abstract class BackupLog extends ActivityLog
{
}