<?php

namespace Inspire\Cmsactivity\recorders;

use Inspire\Cmsactivity\Cmsactivity;
use Inspire\Cmsactivity\base\fieldHandlers\FieldHandler;
use Inspire\Cmsactivity\base\recorders\ConfigModelRecorder;
use craft\events\ConfigEvent;
use craft\services\Fields as CraftFields;
use craft\services\ProjectConfig;
use yii\base\Event;

class Fields extends ConfigModelRecorder
{
    /**
     * @inheritDoc
     */
    protected ?string $deleteTypesCategory = 'fields';

    /**
     * @inheritDoc
     */
    protected array $deleteTypes = ['fieldCreated', 'fieldSaved', 'fieldDeleted'];

    /**
     * @inheritDoc
     */
    public function init(): void
    {
        \Craft::$app->projectConfig->onUpdate(ProjectConfig::PATH_FIELDS . '.{uid}', function (Event $event) {
            Cmsactivity::getRecorder('fields')->onUpdate($event);
        });
        \Craft::$app->projectConfig->onAdd(ProjectConfig::PATH_FIELDS . '.{uid}', function (Event $event) {
            Cmsactivity::getRecorder('fields')->onAdd($event);
        });
        \Craft::$app->projectConfig->onRemove(ProjectConfig::PATH_FIELDS . '.{uid}', function (Event $event) {
            Cmsactivity::getRecorder('fields')->onRemove($event);
        });
    }

    /**
     * @inheritDoc
     */
    protected function getActivityHandle(): string
    {
        return 'field';
    }

    /**
     * @inheritDoc
     */
    protected function getPathFieldHandler(string $path, array $config): string
    {
        $path = explode('.', $path);
        if ($path[2] == 'settings') {
            $path[2] = 'settings[' . $config['type'] .']';
        }
        $path = implode('.', $path);
        return parent::getPathFieldHandler($path, $config);
    }

    /**
     * @inheritDoc
     */
    protected function getHandler(string $baseName, string $path, array $config, $value): FieldHandler
    {
        $class = $this->getPathFieldHandler($path, $config);
        return new $class([
            'value' => $this->typeValue($config, $baseName, $value),
            'data' => [
                'fieldUid' => $this->currentEvent->tokenMatches[0] ?? null
            ]
        ]);
    }

    /**
     * @inheritDoc
     */
    protected function modifyParams(array $params, ConfigEvent $event): array
    {
        $params['target_class'] = $event->newValue['type'] ?? $event->oldValue['type'] ?? '';
        return $params;
    }

    /**
     * @inheritDoc
     */
    protected function getTrackedFieldNames(array $config)
    {
        if (!isset($config['type'])) {
            return Cmsactivity::$plugin->fields->getTrackedFieldNames('_base');
        }
        return Cmsactivity::$plugin->fields->getTrackedFieldNames($config['type']);
    }

    /**
     * @inheritDoc
     */
    protected function getTrackedFieldTypings(array $config): array
    {
        if (!isset($config['type'])) {
            return Cmsactivity::$plugin->fields->getTrackedFieldTypings('_base');
        }
        return Cmsactivity::$plugin->fields->getTrackedFieldTypings($config['type']);
    }

    /**
     * @inheritDoc
     */
    protected function getDescriptiveFieldName(): ?string
    {
        return 'name';
    }
}
