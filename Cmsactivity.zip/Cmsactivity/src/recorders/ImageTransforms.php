<?php

namespace Inspire\Cmsactivity\recorders;

use Inspire\Cmsactivity\Cmsactivity;
use Inspire\Cmsactivity\base\recorders\ConfigModelRecorder;
use craft\services\ProjectConfig;
use yii\base\Event;

class ImageTransforms extends ConfigModelRecorder
{
    /**
     * @inheritDoc
     */
    protected ?string $deleteTypesCategory = 'imageTransforms';

    /**
     * @inheritDoc
     */
    protected array $deleteTypes = ['imageTransformDeleted', 'imageTransformSaved', 'imageTransformCreated'];

    /**
     * @inheritDoc
     */
    public function init(): void
    {
        \Craft::$app->projectConfig->onUpdate(ProjectConfig::PATH_IMAGE_TRANSFORMS . '.{uid}', function (Event $event) {
            Cmsactivity::getRecorder('imageTransforms')->onUpdate($event);
        });
        \Craft::$app->projectConfig->onAdd(ProjectConfig::PATH_IMAGE_TRANSFORMS . '.{uid}', function (Event $event) {
            Cmsactivity::getRecorder('imageTransforms')->onAdd($event);
        });
        \Craft::$app->projectConfig->onRemove(ProjectConfig::PATH_IMAGE_TRANSFORMS . '.{uid}', function (Event $event) {
            Cmsactivity::getRecorder('imageTransforms')->onRemove($event);
        });
    }

    /**
     * @inheritDoc
     */
    protected function getActivityHandle(): string
    {
        return 'imageTransform';
    }

    /**
     * @inheritDoc
     */
    protected function getTrackedFieldNames(array $config): array
    {
        return ['name', 'handle', 'mode', 'position', 'width', 'height', 'quality', 'interlace', 'format'];
    }

    /**
     * @inheritDoc
     */
    protected function getDescriptiveFieldName(): ?string
    {
        return 'name';
    }
}
