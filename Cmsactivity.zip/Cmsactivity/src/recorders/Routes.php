<?php

namespace Inspire\Cmsactivity\recorders;

use Inspire\Cmsactivity\Cmsactivity;
use Inspire\Cmsactivity\base\recorders\ConfigModelRecorder;
use craft\services\ProjectConfig;
use yii\base\Event;

class Routes extends ConfigModelRecorder
{
    /**
     * @inheritDoc
     */
    public function init(): void
    {
        \Craft::$app->projectConfig->onAdd(ProjectConfig::PATH_ROUTES . '.{uid}', function (Event $event) {
            Cmsactivity::getRecorder('routes')->onAdd($event);
        });
        \Craft::$app->projectConfig->onUpdate(ProjectConfig::PATH_ROUTES . '.{uid}', function (Event $event) {
            Cmsactivity::getRecorder('routes')->onUpdate($event);
        });
        \Craft::$app->projectConfig->onRemove(ProjectConfig::PATH_ROUTES . '.{uid}', function (Event $event) {
            Cmsactivity::getRecorder('routes')->onRemove($event);
        });
    }

    /**
     * @inheritDoc
     */
    protected function getActivityHandle(): string
    {
        return 'route';
    }

    /**
     * @inheritDoc
     */
    protected function getTrackedFieldNames(array $config): array
    {
        return ['siteUid', 'uriParts', 'template'];
    }
}