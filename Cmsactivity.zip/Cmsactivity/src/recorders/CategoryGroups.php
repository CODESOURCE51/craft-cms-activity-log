<?php

namespace Inspire\Cmsactivity\recorders;

use Inspire\Cmsactivity\Cmsactivity;
use Inspire\Cmsactivity\base\recorders\ConfigModelRecorder;
use craft\services\ProjectConfig;
use yii\base\Event;

class CategoryGroups extends ConfigModelRecorder
{
    /**
     * @inheritDoc
     */
    protected ?string $deleteTypesCategory = 'categoryGroups';

    /**
     * @inheritDoc
     */
    protected array $deleteTypes = ['categoryGroupCreated', 'categoryGroupSaved', 'categoryGroupDeleted'];

    /**
     * @inheritDoc
     */
    public function init(): void
    {
        \Craft::$app->projectConfig->onUpdate(ProjectConfig::PATH_CATEGORY_GROUPS . '.{uid}', function (Event $event) {
            Cmsactivity::getRecorder('categoryGroups')->onUpdate($event);
        });
        \Craft::$app->projectConfig->onAdd(ProjectConfig::PATH_CATEGORY_GROUPS . '.{uid}', function (Event $event) {
            Cmsactivity::getRecorder('categoryGroups')->onAdd($event);
        });
        \Craft::$app->projectConfig->onRemove(ProjectConfig::PATH_CATEGORY_GROUPS . '.{uid}', function (Event $event) {
            Cmsactivity::getRecorder('categoryGroups')->onRemove($event);
        });
    }

    /**
     * @inheritDoc
     */
    protected function getActivityHandle(): string
    {
        return 'categoryGroup';
    }

    /**
     * @inheritDoc
     */
    protected function getTrackedFieldNames(array $config): array
    {
        return ['name', 'handle', 'structure.maxLevels', 'defaultPlacement', 'siteSettings', 'fieldLayouts'];
    }

    /**
     * @inheritDoc
     */
    protected function getDescriptiveFieldName(): ?string
    {
        return 'name';
    }
}
