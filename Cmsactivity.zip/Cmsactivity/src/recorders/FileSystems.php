<?php

namespace Inspire\Cmsactivity\recorders;

use Inspire\Cmsactivity\Cmsactivity;
use Inspire\Cmsactivity\base\recorders\ConfigModelRecorder;
use craft\events\ConfigEvent;
use craft\services\ProjectConfig;
use yii\base\Event;

class FileSystems extends ConfigModelRecorder
{
    /**
     * @inheritDoc
     */
    protected ?string $deleteTypesCategory = 'filesystems';

    /**
     * @inheritDoc
     */
    protected array $deleteTypes = ['filesystemCreated', 'filesystemSaved', 'filesystemDeleted'];

    /**
     * @inheritDoc
     */
    public function init(): void
    {
        \Craft::$app->projectConfig->onUpdate(ProjectConfig::PATH_FS . '.{uid}', function (Event $event) {
            Cmsactivity::getRecorder('fileSystems')->onFsUpdate($event);
        });
        \Craft::$app->projectConfig->onAdd(ProjectConfig::PATH_FS . '.{uid}', function (Event $event) {
            Cmsactivity::getRecorder('fileSystems')->onFsAdd($event);
        });
        \Craft::$app->projectConfig->onRemove(ProjectConfig::PATH_FS . '.{uid}', function (Event $event) {
            Cmsactivity::getRecorder('fileSystems')->onFsRemove($event);
        });
    }

    public function onFsUpdate(ConfigEvent $event)
    {
        $event->oldValue['handle'] = $event->tokenMatches[0];
        $event->newValue['handle'] = $event->tokenMatches[0];
        $this->onUpdate($event);
    }

    public function onFsAdd(ConfigEvent $event)
    {
        $event->newValue['handle'] = $event->tokenMatches[0];
        $this->onAdd($event);
    }

    public function onFsRemove(ConfigEvent $event)
    {
        $event->oldValue['handle'] = $event->tokenMatches[0];
        $this->onRemove($event);
    }

    /**
     * @inheritDoc
     */
    protected function getActivityHandle(): string
    {
        return 'filesystem';
    }

    /**
     * @inheritDoc
     */
    protected function getTrackedFieldNames(array $config): array
    {
        return ['name', 'handle', 'hasUrls', 'settings.path', 'type', 'url'];
    }

    /**
     * @inheritDoc
     */
    protected function getDescriptiveFieldName(): ?string
    {
        return 'name';
    }
}
