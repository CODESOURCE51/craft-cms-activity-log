<?php

namespace Inspire\Cmsactivity\recorders;

use Inspire\Cmsactivity\Cmsactivity;
use Inspire\Cmsactivity\base\recorders\ProjectConfigRecorder;
use craft\web\Application;
use yii\base\Event;

class GeneralSettings extends ProjectConfigRecorder
{
    /**
     * @inheritDoc
     */
    public function init(): void
    {
        \Craft::$app->projectConfig->onUpdate('system', function(Event $event) {
            Cmsactivity::getRecorder('generalSettings')->onConfigChanged('system', 'generalSettingsChanged', $event->oldValue, $event->newValue);
        });
    }
    
    /**
     * @inheritDoc
     */
    protected function getTrackedFieldNames(array $config): array
    {
        return ['live', 'name', 'retryDuration', 'timeZone'];
    }
}