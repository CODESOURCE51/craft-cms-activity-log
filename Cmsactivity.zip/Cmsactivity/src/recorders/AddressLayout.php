<?php

namespace Inspire\Cmsactivity\recorders;

use Inspire\Cmsactivity\Cmsactivity;
use Inspire\Cmsactivity\base\recorders\ConfigModelRecorder;
use craft\events\ConfigEvent;
use craft\services\ProjectConfig;
use yii\base\Event;

class AddressLayout extends ConfigModelRecorder
{
    /**
     * @inheritDoc
     */
    public function init(): void
    {
        \Craft::$app->projectConfig->onUpdate(ProjectConfig::PATH_ADDRESSES, function(Event $event) {
            Cmsactivity::getRecorder('addressLayout')->onUpdate($event);
        });
        \Craft::$app->projectConfig->onAdd(ProjectConfig::PATH_ADDRESSES, function(Event $event) {
            Cmsactivity::getRecorder('addressLayout')->onUpdate($event);
        });
        \Craft::$app->projectConfig->onAdd(ProjectConfig::PATH_ADDRESSES, function(Event $event) {
            Cmsactivity::getRecorder('addressLayout')->onUpdate($event);
        });
    }

    public function onUpdate(ConfigEvent $event)
    {
        $event->path = ProjectConfig::PATH_ADDRESSES;
        parent::onUpdate($event);
    }

    /**
     * @inheritDoc
     */
    protected function getActivityHandle(): string
    {
        return 'addressLayout';
    }

    /**
     * @inheritDoc
     */
    protected function getTrackedFieldNames(array $config): array
    {
        return ['fieldLayouts'];
    }
}