<?php

namespace Inspire\Cmsactivity\twig;

use Inspire\Cmsactivity\Cmsactivity;
use Inspire\Cmsactivity\helpers\PrettyPrint;
use Inspire\Cmsactivity\services\Logs;
use craft\helpers\Json;

/**
 * @since 2.2.0
 */
class TwigActivity
{
    /**
     * Get the current twig context, can be 'web' or 'export'
     *
     * @since  2.3.5
     * @return string
     */
    public function getContext(): string
    {
        return Cmsactivity::$plugin->twigContext;
    }

    /**
     * Get logs service
     *
     * @return Logs
     */
    public function getLogs(): Logs
    {
        return Cmsactivity::$plugin->logs;
    }

    /**
     * Show user IPs
     *
     * @since 2.3.4
     * @return bool
     */
    public function showUserIP(): bool
    {
        return Cmsactivity::$plugin->settings->showUserIP;
    }

    /**
     * Return an element value
     *
     * @param   $value
     * @return string
     * @since 2.3.10
     */
    public function elementValue($value): string
    {
        if (is_array($value)) {
            return Json::encode($value);
        } else {
            $value = PrettyPrint::get($value);
        }
        return $value;
    }

    /**
     * returns the version of Activity
     *
     * @return string
     * @since 2.3.15
     */
    public function getVersion(): string
    {
        return Cmsactivity::$plugin->version;
    }

    /**
     * Compare a version to the Activity plugin version
     *
     * @param  string $version
     * @return bool
     * @since  2.3.15
     */
    public function versionCompare(string $version, string $operator): bool
    {
        return version_compare($this->getVersion(), $version, $operator);
    }
}
