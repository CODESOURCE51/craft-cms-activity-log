<?php

namespace Inspire\Cmsactivity\models\logs\routes;

class RouteSaved extends RouteCreated
{   
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Saved route {uid}', [
            'uid' => $this->target_uid
        ]);
    }
}