<?php

namespace Inspire\Cmsactivity\models\logs\assets;

class FilesystemSaved extends FilesystemCreated
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Saved filesystem {name}', ['name' => $this->modelName]);
    }
}