<?php

namespace Inspire\Cmsactivity\models\logs\assets;

class ImageTransformDeleted extends ImageTransformCreated
{   
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Deleted image transform {name}', ['name' => $this->target_name]);
    }
}