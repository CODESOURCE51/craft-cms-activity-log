<?php

namespace Inspire\Cmsactivity\models\logs\assets;

class VolumeSaved extends VolumeCreated
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Saved volume {name}', ['name' => $this->modelName]);
    }
}