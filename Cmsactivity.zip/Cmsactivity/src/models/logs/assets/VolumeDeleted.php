<?php

namespace Inspire\Cmsactivity\models\logs\assets;

class VolumeDeleted extends VolumeCreated
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Deleted volume {name}', ['name' => $this->target_name]);
    }
}