<?php

namespace Inspire\Cmsactivity\models\logs\assets;

use Inspire\Cmsactivity\base\logs\AssetLog;

class AssetDeleted extends AssetLog
{
}