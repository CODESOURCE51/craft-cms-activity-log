<?php

namespace Inspire\Cmsactivity\models\logs\assets;

class ImageTransformSaved extends ImageTransformCreated
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Saved image transform {name}', ['name' => $this->modelName]);
    }
}