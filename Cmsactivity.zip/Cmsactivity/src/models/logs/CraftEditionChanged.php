<?php

namespace Inspire\Cmsactivity\models\logs;

use Inspire\Cmsactivity\base\logs\ActivityLog;

class CraftEditionChanged extends ActivityLog
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        $changed = $this->changedFields[0] ?? null;
        if (!$changed) {
            return \Craft::t('cmsactivity', 'Changed Craft edition');
        }
        $pro = \Craft::t('cmsactivity', 'Pro');
        $solo = \Craft::t('cmsactivity', 'Solo');
        return \Craft::t('cmsactivity', 'Changed Craft edition from {from} to {to}', [
            'from' => $changed->data['f'] == 'pro' ? $pro : $solo,
            'to' => $changed->data['t'] == 'pro' ? $pro : $solo
        ]);
    }
}