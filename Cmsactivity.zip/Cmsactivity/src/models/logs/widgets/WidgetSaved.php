<?php

namespace Inspire\Cmsactivity\models\logs\widgets;

class WidgetSaved extends WidgetCreated
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Saved widget {name}', ['name' => $this->target_name]);
    }
}