<?php

namespace Inspire\Cmsactivity\models\logs\settings;

use Inspire\Cmsactivity\base\logs\SettingsLog;

class GeneralSettingsChanged extends SettingsLog
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Changed general settings');
    }

    /**
     * @inheritDoc
     */
    public function getSettingLabels(): array
    {
        return [
            'name' => \Craft::t('app', 'System Name'),
            'live' => \Craft::t('app', 'System Status'),
            'edition' => \Craft::t('app', 'Edition'),
            'retryDuration' => \Craft::t('app', 'Retry Duration'),
            'timeZone' => \Craft::t('app', 'Time Zone'),
            'schemaVersion' => \Craft::t('cmsactivity', 'Schema version'),
        ];
    }
}