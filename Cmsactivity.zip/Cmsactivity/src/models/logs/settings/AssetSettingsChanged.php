<?php

namespace Inspire\Cmsactivity\models\logs\settings;

use Inspire\Cmsactivity\base\logs\SettingsLog;

class AssetSettingsChanged extends SettingsLog
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Changed asset settings');
    }

    /**
     * @inheritDoc
     */
    public function getSettingLabels(): array
    {
        return [
            'tempSubpath' => \Craft::t('cmsactivity', 'Temp Uploads Location Subpath'),
            'tempVolumeUid' => \Craft::t('app', 'Temp Uploads Location')
        ];
    }
}