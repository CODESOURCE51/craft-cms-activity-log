<?php

namespace Inspire\Cmsactivity\models\logs;

use Inspire\Cmsactivity\base\logs\ActivityLog;

class MissingType extends ActivityLog
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return '<i>' . \Craft::t('cmsactivity', 'Data missing') . '</i>';
    }
}