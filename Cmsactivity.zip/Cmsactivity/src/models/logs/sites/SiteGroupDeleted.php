<?php

namespace Inspire\Cmsactivity\models\logs\sites;

class SiteGroupDeleted extends SiteGroupCreated
{   
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Deleted site group {name}', ['name' => $this->target_name]);
    }
}