<?php

namespace Inspire\Cmsactivity\models\logs\sites;

class SiteGroupSaved extends SiteGroupCreated
{   
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Saved site group {name}', ['name' => $this->modelName]);
    }
}