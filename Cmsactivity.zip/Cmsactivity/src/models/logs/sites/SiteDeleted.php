<?php

namespace Inspire\Cmsactivity\models\logs\sites;

class SiteDeleted extends SiteCreated
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Deleted site {name}', ['name' => $this->target_name]);
    }
}