<?php

namespace Inspire\Cmsactivity\models\logs\tags;

class TagGroupSaved extends TagGroupCreated
{   
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Saved tag group {name}', ['name' => $this->modelName]);
    }
}