<?php

namespace Inspire\Cmsactivity\models\logs\tags;

class TagGroupDeleted extends TagGroupCreated
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Deleted tag group {name}', ['name' => $this->target_name]);
    }
}