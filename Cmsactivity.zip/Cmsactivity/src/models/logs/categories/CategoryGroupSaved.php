<?php

namespace Inspire\Cmsactivity\models\logs\categories;

class CategoryGroupSaved extends CategoryGroupCreated
{   
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Saved category group {name}', ['name' => $this->modelName]);
    }
}