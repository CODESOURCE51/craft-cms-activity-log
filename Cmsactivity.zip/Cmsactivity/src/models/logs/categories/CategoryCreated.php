<?php

namespace Inspire\Cmsactivity\models\logs\categories;

use Inspire\Cmsactivity\base\logs\CategoryLog;

class CategoryCreated extends CategoryLog
{
}