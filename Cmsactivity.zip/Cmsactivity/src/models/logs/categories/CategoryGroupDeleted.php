<?php

namespace Inspire\Cmsactivity\models\logs\categories;

class CategoryGroupDeleted extends CategoryGroupCreated
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Deleted category group {name}', ['name' => $this->target_name]);
    }
}