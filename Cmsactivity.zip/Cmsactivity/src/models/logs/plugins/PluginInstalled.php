<?php

namespace Inspire\Cmsactivity\models\logs\plugins;

use Inspire\Cmsactivity\base\logs\PluginLog;

class PluginInstalled extends PluginLog
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Installed plugin {name}', ['name' => $this->pluginName]);
    }
}