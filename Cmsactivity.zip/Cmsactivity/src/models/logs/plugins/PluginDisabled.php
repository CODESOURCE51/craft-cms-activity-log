<?php

namespace Inspire\Cmsactivity\models\logs\plugins;

use Inspire\Cmsactivity\base\logs\PluginLog;

class PluginDisabled extends PluginLog
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Disabled plugin {name}', ['name' => $this->pluginName]);
    }
}