<?php

namespace Inspire\Cmsactivity\models\logs\plugins;

use Inspire\Cmsactivity\base\logs\PluginLog;

class PluginEditionChanged extends PluginLog
{   
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Changed edition for plugin {name} from {from} to {to}', [
            'name' => $this->pluginName,
            'from' => $this->data['old'],
            'to' => $this->data['new']
        ]);
    }
}