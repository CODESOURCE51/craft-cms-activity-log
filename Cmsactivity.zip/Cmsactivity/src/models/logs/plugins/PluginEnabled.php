<?php

namespace Inspire\Cmsactivity\models\logs\plugins;

use Inspire\Cmsactivity\base\logs\PluginLog;

class PluginEnabled extends PluginLog
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Enabled plugin {name}', ['name' => $this->pluginName]);
    }
}