<?php

namespace Inspire\Cmsactivity\models\logs\plugins;

use Inspire\Cmsactivity\base\logs\PluginLog;

class PluginUninstalled extends PluginLog
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Uninstalled plugin {name}', ['name' => $this->pluginName]);
    }
}