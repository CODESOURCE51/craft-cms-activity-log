<?php

namespace Inspire\Cmsactivity\models\logs\addresses;

use Inspire\Cmsactivity\base\logs\AddressLog;

/**
 * @since 3.0.0
 */
class UserAddressCreated extends AddressLog
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Created address {name}', ['name' => $this->elementTitle]);
    }
}
