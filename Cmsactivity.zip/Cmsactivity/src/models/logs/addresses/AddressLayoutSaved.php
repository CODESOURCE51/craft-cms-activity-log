<?php

namespace Inspire\Cmsactivity\models\logs\addresses;

use Inspire\Cmsactivity\base\logs\ActivityLog;

class AddressLayoutSaved extends ActivityLog
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Saved address layout');
    }

    /**
     * @inheritDoc
     */
    public function getDescription(): string
    {
        return \Craft::$app->view->renderTemplate('cmsactivity/descriptions/address-layout', [
            'log' => $this
        ]);
    }
}