<?php

namespace Inspire\Cmsactivity\models\logs\entries;

class EntryTypeSaved extends EntryTypeCreated
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Saved entry type {name}', [
            'name' => $this->modelName
        ]);
    }
}
