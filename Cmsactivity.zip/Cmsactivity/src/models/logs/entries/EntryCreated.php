<?php

namespace Inspire\Cmsactivity\models\logs\entries;

use Inspire\Cmsactivity\base\logs\EntryLog;

class EntryCreated extends EntryLog
{
}