<?php

namespace Inspire\Cmsactivity\models\logs\entries;

class SectionDeleted extends SectionCreated
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Deleted section {name}', ['name' => $this->target_name]);
    }
}