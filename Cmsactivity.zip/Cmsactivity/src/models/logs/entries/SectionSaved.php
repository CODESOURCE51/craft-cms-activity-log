<?php

namespace Inspire\Cmsactivity\models\logs\entries;

class SectionSaved extends SectionCreated
{   
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Saved section {name}', ['name' => $this->modelName]);
    }
}