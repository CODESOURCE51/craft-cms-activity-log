<?php

namespace Inspire\Cmsactivity\models\logs\backups;

use Inspire\Cmsactivity\base\logs\BackupLog;

class BackupRestored extends BackupLog
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Restored database from backup: {file}', [
            'file' => $this->data['file']
        ]);
    }
}