<?php

namespace Inspire\Cmsactivity\models\logs\backups;

use Inspire\Cmsactivity\base\logs\BackupLog;

class BackupCreated extends BackupLog
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Created database backup: {file}', [
            'file' => $this->data['file']
        ]);
    }
}