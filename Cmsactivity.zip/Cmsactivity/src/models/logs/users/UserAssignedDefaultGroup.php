<?php

namespace Inspire\Cmsactivity\models\logs\users;

use Inspire\Cmsactivity\base\logs\UserLog;

class UserAssignedDefaultGroup extends UserLog
{
    /**
     * Group setter
     *
     * @param array $group
     */
    public function setGroup(array $group)
    {
        $this->data['group'] = $group;
    }

    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        $name = $this->data['group']['name'];
        if ($group = \Craft::$app->userGroups->getGroupById($this->data['group']['id'])) {
            $name = $group->name;
        } else {
            $name .= ' (deleted)';
        }
        return \Craft::t('cmsactivity', 'Was assigned to default group {group}', ['group' => $name]);
    }
}
