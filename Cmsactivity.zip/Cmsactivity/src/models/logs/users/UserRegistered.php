<?php

namespace Inspire\Cmsactivity\models\logs\users;

use Inspire\Cmsactivity\base\logs\UserLog;

class UserRegistered extends UserLog
{
}