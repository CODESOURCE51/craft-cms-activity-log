<?php

namespace Inspire\Cmsactivity\models\logs\users;

use Inspire\Cmsactivity\base\logs\UserLog;

class UserLocked extends UserLog
{       
    /**
     * Attempts setter
     * 
     * @param int $attempts
     */
    public function setAttempts(int $attempts)
    {
        $this->data = [
            'attempts' => $attempts
        ];
    }

    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Was locked after {number} login attempt', ['number' => $this->data['attempts']]);
    }
}