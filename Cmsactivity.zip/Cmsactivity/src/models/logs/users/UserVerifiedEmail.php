<?php

namespace Inspire\Cmsactivity\models\logs\users;

use Inspire\Cmsactivity\base\logs\UserLog;

class UserVerifiedEmail extends UserLog
{   
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Verified email');
    }
}