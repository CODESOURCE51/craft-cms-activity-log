<?php

namespace Inspire\Cmsactivity\models\logs\users;

use Inspire\Cmsactivity\base\logs\UserLog;

class UserSaved extends UserLog
{
}