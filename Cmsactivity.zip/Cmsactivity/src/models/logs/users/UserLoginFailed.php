<?php

namespace Inspire\Cmsactivity\models\logs\users;

use Inspire\Cmsactivity\base\logs\UserLog;

class UserLoginFailed extends UserLog
{   
    /**
     * @inheritDoc
     */
    public function getName(): string
    {
        return \Craft::t('cmsactivity', 'User failed to login');
    }

    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Failed to login');
    }
}