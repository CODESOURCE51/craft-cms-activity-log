<?php

namespace Inspire\Cmsactivity\models\logs\users;

class UserGroupDeleted extends UserGroupCreated
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Deleted user group {name}', ['name' => $this->target_name]);
    }
}