<?php

namespace Inspire\Cmsactivity\models\logs\users;

use Inspire\Cmsactivity\base\logs\UserLog;

class UserAssignedGroups extends UserLog
{
    /**
     * Removed groups setter
     *
     * @param array $groups
     * @since 2.3.9
     */
    public function setRemovedGroups(array $groups)
    {
        $this->data['removedGroups'] = $groups;
    }

    /**
     * New groups setter
     *
     * @param array $groups
     * @since 2.3.9
     */
    public function setNewGroups(array $groups)
    {
        $this->data['newGroups'] = $groups;
    }

    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Assigned user {title} to groups', ['title' => $this->elementTitle]);
    }

    /**
     * @inheritDoc
     */
    public function getDescription(): string
    {
        return \Craft::$app->view->renderTemplate('cmsactivity/descriptions/user-groups', [
            'log' => $this,
            'newGroups' => $this->getGroupNames($this->data['newGroups'] ?? []),
            'removedGroups' => $this->getGroupNames($this->data['removedGroups'] ?? []),
        ]);
    }

    /**
     * Get group names from an array of data
     *
     * @param  array  $data
     * @return array
     * @since 2.3.9
     */
    protected function getGroupNames(array $data): string
    {
        $names = [];
        foreach ($data as $data) {
            $name = $data['name'];
            if ($group = \Craft::$app->userGroups->getGroupById($data['id'])) {
                $name = $group->name;
            } else {
                $name = \Craft::t('cmsactivity', '{group} (deleted)', ['group' => $name]);
            }
            $names[] = $name;
        }
        return implode(', ', $names);
    }
}
