<?php

namespace Inspire\Cmsactivity\models\logs\users;

use Inspire\Cmsactivity\base\logs\SettingsLog;

class UserSettingsChanged extends SettingsLog
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Changed user settings');
    }

    /**
     * @inheritDoc
     */
    public function getSettingLabels(): array
    {
        return [
            'photoSubpath' => \Craft::t('cmsactivity', 'User Photo Location subfolder'),
            'photoVolumeUid' => \Craft::t('app', 'User Photo Location'),
            'requireEmailVerification' => \Craft::t('app', 'Verify email addresses'),
            'allowPublicRegistration' => \Craft::t('app', 'Allow public registration'),
            'validateOnPublicRegistration' => \Craft::t('app', 'Validate custom fields on public registration'),
            'suspendByDefault' => \Craft::t('app', 'Suspend users by default'),
            'defaultGroup' => \Craft::t('app', 'Default User Group'),
        ];
    }
}