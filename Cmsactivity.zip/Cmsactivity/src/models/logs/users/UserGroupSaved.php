<?php

namespace Inspire\Cmsactivity\models\logs\users;

class UserGroupSaved extends UserGroupCreated
{   
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Saved user group {name}', ['name' => $this->modelName]);
    }
}