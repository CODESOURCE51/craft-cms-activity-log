<?php

namespace Inspire\Cmsactivity\models\logs\fields;

class FieldSaved extends FieldCreated
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Saved field {name}', ['name' => $this->modelName]);
    }
}