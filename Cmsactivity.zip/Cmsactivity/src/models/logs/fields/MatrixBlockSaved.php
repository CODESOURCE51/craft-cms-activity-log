<?php

namespace Inspire\Cmsactivity\models\logs\fields;

/**
 * @since 2.2.0
 * @deprecated in 3.0.0
 */
class MatrixBlockSaved extends MatrixBlockCreated
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Saved matrix block {name} in field {field}', [
            'name' => $this->modelName,
            'field' => $this->fieldName
        ]);
    }
}
