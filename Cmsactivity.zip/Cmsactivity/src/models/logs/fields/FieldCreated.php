<?php

namespace Inspire\Cmsactivity\models\logs\fields;

use Inspire\Cmsactivity\Cmsactivity;
use Inspire\Cmsactivity\base\logs\ConfigModelLog;
use craft\base\Model;
use craft\helpers\UrlHelper;

class FieldCreated extends ConfigModelLog
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Created field {name}', ['name' => $this->modelName]);
    }

    /**
     * @inheritDoc
     */
    protected function getModelLink(): string
    {
        return UrlHelper::cpUrl('settings/fields/edit/' . $this->model->id);
    }

    /**
     * @inheritDoc
     */
    protected function loadModel(): ?Model
    {
        return \Craft::$app->fields->getFieldByUid($this->target_uid);
    }

    /**
     * @inheritDoc
     */
    protected function getFieldLabels(): array
    {
        $type = $this->target_class ?: '_base';
        return Cmsactivity::$plugin->fields->getFieldLabels($type);
    }
}