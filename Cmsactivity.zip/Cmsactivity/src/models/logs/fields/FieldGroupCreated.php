<?php

namespace Inspire\Cmsactivity\models\logs\fields;

use Inspire\Cmsactivity\base\logs\ConfigModelLog;
use craft\base\Model;
use craft\helpers\UrlHelper;

/**
 * @deprecated in 3.0.0
 */
class FieldGroupCreated extends ConfigModelLog
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Created field group {name}', ['name' => $this->modelName]);
    }

    /**
     * @inheritDoc
     */
    protected function getModelLink(): string
    {
        return UrlHelper::cpUrl('settings/fields/' . $this->model->id);
    }

    /**
     * @inheritDoc
     */
    protected function loadModel(): ?Model
    {
        return null;
    }

    /**
     * @inheritDoc
     */
    protected function getFieldLabels(): array
    {
        return [
            'name' => \Craft::t('app', 'Name')
        ];
    }
}
