<?php

namespace Inspire\Cmsactivity\models\logs\fields;

/**
 * @deprecated in 3.0.0
 */
class FieldGroupDeleted extends FieldGroupCreated
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Deleted field group {name}', ['name' => $this->target_name]);
    }
}
