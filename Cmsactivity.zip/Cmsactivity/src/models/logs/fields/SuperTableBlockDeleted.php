<?php

namespace Inspire\Cmsactivity\models\logs\fields;

/**
 * @since 2.2.0
 * @deprecated in 3.0.0
 */
class SuperTableBlockDeleted extends SuperTableBlockCreated
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Deleted super table block in field {field}', [
            'field' => $this->fieldName
        ]);
    }
}
