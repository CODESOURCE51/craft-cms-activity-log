<?php

namespace Inspire\Cmsactivity\models\logs\fields;

/**
 * @since 2.2.0
 * @deprecated in 3.0.0
 */
class SuperTableBlockSaved extends SuperTableBlockCreated
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Saved super table block in field {field}', [
            'field' => $this->fieldName
        ]);
    }
}
