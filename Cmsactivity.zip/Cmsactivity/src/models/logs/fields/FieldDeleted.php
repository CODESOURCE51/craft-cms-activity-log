<?php

namespace Inspire\Cmsactivity\models\logs\fields;

class FieldDeleted extends FieldCreated
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Deleted field {name}', ['name' => $this->target_name]);
    }
}