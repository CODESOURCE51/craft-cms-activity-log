<?php

namespace Inspire\Cmsactivity\models\logs\globals;

use Inspire\Cmsactivity\base\logs\GlobalLog;

class GlobalDeleted extends GlobalLog
{
}