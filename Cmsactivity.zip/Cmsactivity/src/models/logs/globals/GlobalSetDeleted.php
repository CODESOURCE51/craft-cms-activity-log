<?php

namespace Inspire\Cmsactivity\models\logs\globals;

class GlobalSetDeleted extends GlobalSetCreated
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Deleted global set {name}', ['name' => $this->target_name]);
    }
}