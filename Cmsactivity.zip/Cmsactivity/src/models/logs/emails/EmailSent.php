<?php

namespace Inspire\Cmsactivity\models\logs\emails;

use Inspire\Cmsactivity\base\logs\EmailLog;

class EmailSent extends EmailLog
{
    /**
     * @inheritDoc
     */
    public function getTitle(): string
    {
        return \Craft::t('cmsactivity', 'Sent email "{subject}"', [
            'subject' => $this->data['subject']
        ]);
    }
}