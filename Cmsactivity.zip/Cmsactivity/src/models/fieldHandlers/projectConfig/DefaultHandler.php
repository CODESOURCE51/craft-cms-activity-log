<?php

namespace Inspire\Cmsactivity\models\fieldHandlers\projectConfig;

use Inspire\Cmsactivity\base\fieldHandlers\FieldHandler;

class DefaultHandler extends FieldHandler
{
}