<?php

namespace Inspire\Cmsactivity\models\fieldHandlers\elements;

use Inspire\Cmsactivity\base\fieldHandlers\ElementFieldHandler;

class TableDate extends ElementFieldHandler
{
    /**
     * @inheritDoc
     */
    public function init(): void
    {
        $datetime = \DateTime::createFromFormat('Y-m-d H:i:s', $this->value);
        if ($datetime) {
            $this->value = $datetime->format('Y-m-d');
        }
    }
}