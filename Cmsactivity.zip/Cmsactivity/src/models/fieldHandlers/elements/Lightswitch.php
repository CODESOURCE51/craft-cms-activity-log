<?php

namespace Inspire\Cmsactivity\models\fieldHandlers\elements;

use Inspire\Cmsactivity\base\fieldHandlers\ElementFieldHandler;
use craft\fields\Lightswitch as LightswitchField;

class Lightswitch extends ElementFieldHandler
{
    /**
     * @inheritDoc
     */
    protected static function _getTargets(): array
    {
        return [
            LightswitchField::class,
        ];
    }

    /**
     * @inheritDoc
     */
    public static function getTemplate(): ?string
    {
        return 'cmsactivity/field-handlers/lightswitch';
    }
}