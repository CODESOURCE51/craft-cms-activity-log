<?php

namespace Inspire\Cmsactivity\models\fieldHandlers\elements;

use Inspire\Cmsactivity\base\fieldHandlers\ElementsFieldHandler;
use craft\fields\Entries as EntriesField;

class Entries extends ElementsFieldHandler
{
    /**
     * @inheritDoc
     */
    protected static function _getTargets(): array
    {
        return [
            EntriesField::class
        ];
    }

    /**
     * @inheritDoc
     */
    public static function getTemplate(): ?string
    {
        return 'cmsactivity/field-handlers/entries-field';
    }
}