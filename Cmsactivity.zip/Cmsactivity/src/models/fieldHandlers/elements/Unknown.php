<?php

namespace Inspire\Cmsactivity\models\fieldHandlers\elements;

use Inspire\Cmsactivity\base\fieldHandlers\ElementFieldHandler;
use Inspire\Cmsactivity\base\fieldHandlers\FieldHandler;

class Unknown extends ElementFieldHandler
{
    /**
     * @inheritDoc
     */
    public function isDirty(FieldHandler $handler): bool
    {
        if (get_class($handler) != get_class($this)) {
            return true;
        }
        return false;
    }
}
