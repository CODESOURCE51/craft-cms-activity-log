<?php

namespace Inspire\Cmsactivity\models\fieldHandlers\elements;

use Inspire\Cmsactivity\base\fieldHandlers\ElementFieldHandler;
use craft\fields\PlainText as PlainTextField;

class PlainText extends ElementFieldHandler
{
    /**
     * @inheritDoc
     */
    protected static function _getTargets(): array
    {
        return [
            PlainTextField::class
        ];
    }

    /**
     * @inheritDoc
     */
    public static function getTemplate(): ?string
    {
        return 'cmsactivity/field-handlers/plaintext-field';
    }
}