<?php

namespace Inspire\Cmsactivity\models\fieldHandlers\elements;

use Inspire\Cmsactivity\base\fieldHandlers\ElementsFieldHandler;
use craft\fields\Categories as CategoriesField;

class Categories extends ElementsFieldHandler
{
    /**
     * @inheritDoc
     */
    protected static function _getTargets(): array
    {
        return [
            CategoriesField::class
        ];
    }

    /**
     * @inheritDoc
     */
    public static function getTemplate(): ?string
    {
        return 'cmsactivity/field-handlers/categories-field';
    }
}