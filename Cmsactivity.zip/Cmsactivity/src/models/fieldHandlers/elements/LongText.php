<?php

namespace Inspire\Cmsactivity\models\fieldHandlers\elements;

use Inspire\Cmsactivity\base\fieldHandlers\ElementFieldHandler;

/**
 * @since 2.1.0
 */
class LongText extends ElementFieldHandler 
{
    /**
     * @inheritDoc
     */
    public static function getTemplate(): ?string
    {
        return 'cmsactivity/field-handlers/longtext-field';
    }
}