<?php

namespace Inspire\Cmsactivity\events;

use Inspire\Cmsactivity\base\recorders\Recorder;
use Inspire\Cmsactivity\exceptions\ActivityRecorderException;
use Inspire\Cmsactivity\recorders\AddressLayout;
use Inspire\Cmsactivity\recorders\Application;
use Inspire\Cmsactivity\recorders\AssetSettings;
use Inspire\Cmsactivity\recorders\Assets;
use Inspire\Cmsactivity\recorders\Backup;
use Inspire\Cmsactivity\recorders\Categories;
use Inspire\Cmsactivity\recorders\CategoryGroups;
use Inspire\Cmsactivity\recorders\Dashboard;
use Inspire\Cmsactivity\recorders\EmailSettings;
use Inspire\Cmsactivity\recorders\Entries;
use Inspire\Cmsactivity\recorders\EntryTypes;
use Inspire\Cmsactivity\recorders\Fields;
use Inspire\Cmsactivity\recorders\FileSystems;
use Inspire\Cmsactivity\recorders\GeneralSettings;
use Inspire\Cmsactivity\recorders\GlobalSets;
use Inspire\Cmsactivity\recorders\Globals;
use Inspire\Cmsactivity\recorders\ImageTransforms;
use Inspire\Cmsactivity\recorders\Mailer;
use Inspire\Cmsactivity\recorders\Plugins;
use Inspire\Cmsactivity\recorders\Routes;
use Inspire\Cmsactivity\recorders\Sections;
use Inspire\Cmsactivity\recorders\SiteGroups;
use Inspire\Cmsactivity\recorders\Sites;
use Inspire\Cmsactivity\recorders\Tags;
use Inspire\Cmsactivity\recorders\UserAddresses;
use Inspire\Cmsactivity\recorders\UserGroups;
use Inspire\Cmsactivity\recorders\UserGroupsPermissions;
use Inspire\Cmsactivity\recorders\UserLayout;
use Inspire\Cmsactivity\recorders\UserSettings;
use Inspire\Cmsactivity\recorders\Users;
use Inspire\Cmsactivity\recorders\Volumes;
use yii\base\Event;

class RegisterRecordersEvent extends Event
{
    /**
     * @var array
     */
    protected $_recorders = [];

    /**
     * @inheritDoc
     */
    public function init()
    {
        parent::init();
        $this->addMany([
            'addressLayout' => new AddressLayout(),
            'sites' => new Sites(),
            'siteGroups' => new SiteGroups(),
            'application' => new Application(),
            'assets' => new Assets(),
            'assetSettings' => new AssetSettings(),
            'backup' => new Backup(),
            'categories' => new Categories(),
            'categoryGroups' => new CategoryGroups(),
            'dashboard' => new Dashboard(),
            'entries' => new Entries(),
            'entryTypes' => new EntryTypes(),
            'emailSettings' => new EmailSettings(),
            'fields' => new Fields(),
            'fileSystems' => new FileSystems(),
            'globals' => new Globals(),
            'globalSets' => new GlobalSets(),
            'imageTransforms' => new ImageTransforms(),
            'mailer' => new Mailer(),
            'plugins' => new Plugins(),
            'routes' => new Routes(),
            'sections' => new Sections(),
            'generalSettings' => new GeneralSettings(),
            'tags' => new Tags(),
            'users' => new Users(),
            'userAddresses' => new UserAddresses(),
            'userLayout' => new UserLayout(),
            'userGroups' => new UserGroups(),
            'userGroupsPermissions' => new UserGroupsPermissions(),
            'userSettings' => new UserSettings(),
            'volumes' => new Volumes()
        ]);
    }

    /**
     * Get registered recorders
     *
     * @return array
     */
    public function getRecorders(): array
    {
        return $this->_recorders;
    }

    /**
     * Add a recorder to register
     *
     * @param string   $name
     * @param Recorder $recorder
     * @param boolean  $replace
     */
    public function add(string $name, Recorder $recorder, bool $replace = false)
    {
        if (isset($this->_recorders[$name]) and !$replace) {
            throw ActivityRecorderException::registered($name);
        }
        $this->_recorders[$name] = $recorder;
    }

    /**
     * Add many recorders to register
     *
     * @param array   $recorders
     * @param boolean $replace
     */
    public function addMany(array $recorders, bool $replace = false)
    {
        foreach ($recorders as $name => $recorder) {
            $this->add($name, $recorder, $replace);
        }
    }
}
