<?php

namespace Inspire\Cmsactivity\events;

use Inspire\Cmsactivity\exceptions\FieldHandlerException;
use Inspire\Cmsactivity\models\fieldHandlers\elements\Assets;
use Inspire\Cmsactivity\models\fieldHandlers\elements\Categories;
use Inspire\Cmsactivity\models\fieldHandlers\elements\Date;
use Inspire\Cmsactivity\models\fieldHandlers\elements\Entries;
use Inspire\Cmsactivity\models\fieldHandlers\elements\Lightswitch;
use Inspire\Cmsactivity\models\fieldHandlers\elements\ListField;
use Inspire\Cmsactivity\models\fieldHandlers\elements\ListsField;
use Inspire\Cmsactivity\models\fieldHandlers\elements\MatrixNew;
use Inspire\Cmsactivity\models\fieldHandlers\elements\Money;
use Inspire\Cmsactivity\models\fieldHandlers\elements\Plain;
use Inspire\Cmsactivity\models\fieldHandlers\elements\PlainText;
use Inspire\Cmsactivity\models\fieldHandlers\elements\LongText;
use Inspire\Cmsactivity\models\fieldHandlers\elements\Table;
use Inspire\Cmsactivity\models\fieldHandlers\elements\Tags;
use Inspire\Cmsactivity\models\fieldHandlers\elements\Users;
use yii\base\Event;

class RegisterElementFieldHandlersEvent extends Event
{
    /**
     * @var array
     */
    protected $_handlers = [];

    /**
     * @inheritDoc
     */
    public function init()
    {
        parent::init();
        $this->addMany([
            Assets::class,
            Categories::class,
            Date::class,
            Entries::class,
            Lightswitch::class,
            ListField::class,
            ListsField::class,
            LongText::class,
            MatrixNew::class,
            Money::class,
            Plain::class,
            PlainText::class,
            Tags::class,
            Table::class,
            Users::class
        ]);
    }

    /**
     * Get registered field handlers
     * @return array
     */
    public function getHandlers(): array
    {
        return $this->_handlers;
    }

    /**
     * Add a field handler to register
     *
     * @param string  $handler
     * @param boolean $replace
     */
    public function add(string $handler, bool $replace = false)
    {
        foreach ($handler::getTargets() as $target) {
            if (isset($this->_handlers[$target]) and !$replace) {
                throw FieldHandlerException::elementRegistered($target, $this->_handlers[$target]);
            }
            $this->_handlers[$target] = $handler;
        }
    }

    /**
     * Add many field handlers to register
     *
     * @param array   $handlers
     * @param boolean $replace
     */
    public function addMany(array $handlers, bool $replace = false)
    {
        foreach ($handlers as $handler) {
            $this->add($handler, $replace);
        }
    }
}
