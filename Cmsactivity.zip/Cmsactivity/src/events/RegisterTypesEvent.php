<?php

namespace Inspire\Cmsactivity\events;

use Inspire\Cmsactivity\base\logs\ActivityLog;
use Inspire\Cmsactivity\exceptions\ActivityTypeException;
use Inspire\Cmsactivity\models\logs\CraftEditionChanged;
use Inspire\Cmsactivity\models\logs\addresses\AddressLayoutSaved;
use Inspire\Cmsactivity\models\logs\addresses\UserAddressCreated;
use Inspire\Cmsactivity\models\logs\addresses\UserAddressDeleted;
use Inspire\Cmsactivity\models\logs\addresses\UserAddressSaved;
use Inspire\Cmsactivity\models\logs\assets\AssetCreated;
use Inspire\Cmsactivity\models\logs\assets\AssetDeleted;
use Inspire\Cmsactivity\models\logs\assets\AssetSaved;
use Inspire\Cmsactivity\models\logs\assets\FilesystemCreated;
use Inspire\Cmsactivity\models\logs\assets\FilesystemDeleted;
use Inspire\Cmsactivity\models\logs\assets\FilesystemSaved;
use Inspire\Cmsactivity\models\logs\assets\ImageTransformCreated;
use Inspire\Cmsactivity\models\logs\assets\ImageTransformDeleted;
use Inspire\Cmsactivity\models\logs\assets\ImageTransformSaved;
use Inspire\Cmsactivity\models\logs\assets\VolumeCreated;
use Inspire\Cmsactivity\models\logs\assets\VolumeDeleted;
use Inspire\Cmsactivity\models\logs\assets\VolumeSaved;
use Inspire\Cmsactivity\models\logs\backups\BackupCreated;
use Inspire\Cmsactivity\models\logs\backups\BackupRestored;
use Inspire\Cmsactivity\models\logs\categories\CategoryCreated;
use Inspire\Cmsactivity\models\logs\categories\CategoryDeleted;
use Inspire\Cmsactivity\models\logs\categories\CategoryGroupCreated;
use Inspire\Cmsactivity\models\logs\categories\CategoryGroupDeleted;
use Inspire\Cmsactivity\models\logs\categories\CategoryGroupSaved;
use Inspire\Cmsactivity\models\logs\categories\CategoryMoved;
use Inspire\Cmsactivity\models\logs\categories\CategoryRestored;
use Inspire\Cmsactivity\models\logs\categories\CategorySaved;
use Inspire\Cmsactivity\models\logs\emails\EmailFailed;
use Inspire\Cmsactivity\models\logs\emails\EmailSent;
use Inspire\Cmsactivity\models\logs\entries\EntryCreated;
use Inspire\Cmsactivity\models\logs\entries\EntryDeleted;
use Inspire\Cmsactivity\models\logs\entries\EntryMoved;
use Inspire\Cmsactivity\models\logs\entries\EntryRestored;
use Inspire\Cmsactivity\models\logs\entries\EntryReverted;
use Inspire\Cmsactivity\models\logs\entries\EntrySaved;
use Inspire\Cmsactivity\models\logs\entries\EntryTypeCreated;
use Inspire\Cmsactivity\models\logs\entries\EntryTypeDeleted;
use Inspire\Cmsactivity\models\logs\entries\EntryTypeSaved;
use Inspire\Cmsactivity\models\logs\entries\SectionCreated;
use Inspire\Cmsactivity\models\logs\entries\SectionDeleted;
use Inspire\Cmsactivity\models\logs\entries\SectionSaved;
use Inspire\Cmsactivity\models\logs\fields\FieldCreated;
use Inspire\Cmsactivity\models\logs\fields\FieldDeleted;
use Inspire\Cmsactivity\models\logs\fields\FieldGroupCreated;
use Inspire\Cmsactivity\models\logs\fields\FieldGroupDeleted;
use Inspire\Cmsactivity\models\logs\fields\FieldGroupSaved;
use Inspire\Cmsactivity\models\logs\fields\FieldSaved;
use Inspire\Cmsactivity\models\logs\fields\MatrixBlockCreated;
use Inspire\Cmsactivity\models\logs\fields\MatrixBlockDeleted;
use Inspire\Cmsactivity\models\logs\fields\MatrixBlockSaved;
use Inspire\Cmsactivity\models\logs\globals\GlobalDeleted;
use Inspire\Cmsactivity\models\logs\globals\GlobalSaved;
use Inspire\Cmsactivity\models\logs\globals\GlobalSetCreated;
use Inspire\Cmsactivity\models\logs\globals\GlobalSetDeleted;
use Inspire\Cmsactivity\models\logs\globals\GlobalSetSaved;
use Inspire\Cmsactivity\models\logs\plugins\PluginDisabled;
use Inspire\Cmsactivity\models\logs\plugins\PluginEditionChanged;
use Inspire\Cmsactivity\models\logs\plugins\PluginEnabled;
use Inspire\Cmsactivity\models\logs\plugins\PluginInstalled;
use Inspire\Cmsactivity\models\logs\plugins\PluginSettingsChanged;
use Inspire\Cmsactivity\models\logs\plugins\PluginUninstalled;
use Inspire\Cmsactivity\models\logs\routes\RouteCreated;
use Inspire\Cmsactivity\models\logs\routes\RouteDeleted;
use Inspire\Cmsactivity\models\logs\routes\RouteSaved;
use Inspire\Cmsactivity\models\logs\settings\AssetSettingsChanged;
use Inspire\Cmsactivity\models\logs\settings\EmailSettingsChanged;
use Inspire\Cmsactivity\models\logs\settings\GeneralSettingsChanged;
use Inspire\Cmsactivity\models\logs\sites\SiteCreated;
use Inspire\Cmsactivity\models\logs\sites\SiteDeleted;
use Inspire\Cmsactivity\models\logs\sites\SiteGroupCreated;
use Inspire\Cmsactivity\models\logs\sites\SiteGroupDeleted;
use Inspire\Cmsactivity\models\logs\sites\SiteGroupSaved;
use Inspire\Cmsactivity\models\logs\sites\SiteSaved;
use Inspire\Cmsactivity\models\logs\tags\TagGroupCreated;
use Inspire\Cmsactivity\models\logs\tags\TagGroupDeleted;
use Inspire\Cmsactivity\models\logs\tags\TagGroupSaved;
use Inspire\Cmsactivity\models\logs\users\UserActivated;
use Inspire\Cmsactivity\models\logs\users\UserAssignedDefaultGroup;
use Inspire\Cmsactivity\models\logs\users\UserAssignedGroups;
use Inspire\Cmsactivity\models\logs\users\UserCreated;
use Inspire\Cmsactivity\models\logs\users\UserDeactivated;
use Inspire\Cmsactivity\models\logs\users\UserDeleted;
use Inspire\Cmsactivity\models\logs\users\UserGroupCreated;
use Inspire\Cmsactivity\models\logs\users\UserGroupDeleted;
use Inspire\Cmsactivity\models\logs\users\UserGroupPermissionsSaved;
use Inspire\Cmsactivity\models\logs\users\UserGroupSaved;
use Inspire\Cmsactivity\models\logs\users\UserInvalidToken;
use Inspire\Cmsactivity\models\logs\users\UserLayoutSaved;
use Inspire\Cmsactivity\models\logs\users\UserLocked;
use Inspire\Cmsactivity\models\logs\users\UserLoggedIn;
use Inspire\Cmsactivity\models\logs\users\UserLoggedOut;
use Inspire\Cmsactivity\models\logs\users\UserLoginFailed;
use Inspire\Cmsactivity\models\logs\users\UserPermissionsSaved;
use Inspire\Cmsactivity\models\logs\users\UserRegistered;
use Inspire\Cmsactivity\models\logs\users\UserRestored;
use Inspire\Cmsactivity\models\logs\users\UserSaved;
use Inspire\Cmsactivity\models\logs\users\UserSelfActivated;
use Inspire\Cmsactivity\models\logs\users\UserSettingsChanged;
use Inspire\Cmsactivity\models\logs\users\UserSuspended;
use Inspire\Cmsactivity\models\logs\users\UserUnlocked;
use Inspire\Cmsactivity\models\logs\users\UserUnsuspended;
use Inspire\Cmsactivity\models\logs\users\UserVerifiedEmail;
use Inspire\Cmsactivity\models\logs\widgets\WidgetCreated;
use Inspire\Cmsactivity\models\logs\widgets\WidgetDeleted;
use Inspire\Cmsactivity\models\logs\widgets\WidgetSaved;
use yii\base\Event;

class RegisterTypesEvent extends Event
{
    /**
     * @var array
     */
    protected $_types = [];

    /**
     * @inheritDoc
     */
    public function init()
    {
        parent::init();
        $this->addMany([
            new AddressLayoutSaved(),
            new UserAddressCreated(),
            new UserAddressSaved(),
            new UserAddressDeleted(),
            new AssetCreated(),
            new AssetSaved(),
            new AssetDeleted(),
            new AssetSettingsChanged(),
            new BackupCreated(),
            new BackupRestored(),
            new CategoryCreated(),
            new CategorySaved(),
            new CategoryDeleted(),
            new CategoryRestored(),
            new CategoryMoved(),
            new CategoryGroupCreated(),
            new CategoryGroupSaved(),
            new CategoryGroupDeleted(),
            new CraftEditionChanged(),
            new EmailSettingsChanged(),
            new EntryCreated(),
            new EntrySaved(),
            new EntryDeleted(),
            new EntryMoved(),
            new EntryRestored(),
            new EntryTypeCreated(),
            new EntryTypeSaved(),
            new EntryTypeDeleted(),
            new EntryReverted(),
            new EmailSent(),
            new EmailFailed(),
            new FieldCreated(),
            new FieldSaved(),
            new FieldDeleted(),
            new FieldGroupCreated(),
            new FieldGroupSaved(),
            new FieldGroupDeleted(),
            new FilesystemCreated(),
            new FilesystemSaved(),
            new FilesystemDeleted(),
            new GeneralSettingsChanged(),
            new GlobalSetCreated(),
            new GlobalSetSaved(),
            new GlobalSetDeleted(),
            new GlobalSaved(),
            new GlobalDeleted(),
            new ImageTransformCreated(),
            new ImageTransformSaved(),
            new ImageTransformDeleted(),
            new MatrixBlockSaved(),
            new MatrixBlockCreated(),
            new MatrixBlockDeleted(),
            new PluginDisabled(),
            new PluginEnabled(),
            new PluginInstalled(),
            new PluginUninstalled(),
            new PluginSettingsChanged(),
            new PluginEditionChanged(),
            new RouteSaved(),
            new RouteDeleted(),
            new RouteCreated(),
            new SectionDeleted(),
            new SectionCreated(),
            new SectionSaved(),
            new SiteCreated(),
            new SiteSaved(),
            new SiteDeleted(),
            new SiteGroupCreated(),
            new SiteGroupSaved(),
            new SiteGroupDeleted(),
            new TagGroupCreated(),
            new TagGroupSaved(),
            new TagGroupDeleted(),
            new UserSettingsChanged(),
            new UserCreated(),
            new UserSaved(),
            new UserSuspended(),
            new UserUnsuspended(),
            new UserLocked(),
            new UserUnlocked(),
            new UserVerifiedEmail(),
            new UserActivated(),
            new UserDeactivated(),
            new UserSelfActivated(),
            new UserRestored(),
            new UserDeleted(),
            new UserAssignedGroups(),
            new UserAssignedDefaultGroup(),
            new UserRegistered(),
            new UserLoginFailed(),
            new UserInvalidToken(),
            new UserGroupCreated(),
            new UserGroupSaved(),
            new UserGroupDeleted(),
            new UserGroupPermissionsSaved(),
            new UserLayoutSaved(),
            new UserPermissionsSaved(),
            new UserLoggedIn(),
            new UserLoggedOut(),
            new VolumeCreated(),
            new VolumeSaved(),
            new VolumeDeleted(),
            new WidgetCreated(),
            new WidgetSaved(),
            new WidgetDeleted(),
        ]);
    }

    /**
     * Get registered types
     *
     * @return array
     */
    public function getTypes(): array
    {
        return $this->_types;
    }

    /**
     * Add a type to register
     *
     * @param ActivityLog $type
     * @param boolean     $replace
     */
    public function add(ActivityLog $type, bool $replace = false)
    {
        if (isset($this->_types[$type->handle]) and !$replace) {
            throw ActivityTypeException::registered($type->handle, get_class($type));
        }
        $this->_types[$type->handle] = get_class($type);
    }

    /**
     * Add many types to register
     *
     * @param array   $types
     * @param boolean $replace
     */
    public function addMany(array $types, bool $replace = false)
    {
        foreach ($types as $type) {
            $this->add($type, $replace);
        }
    }
}
